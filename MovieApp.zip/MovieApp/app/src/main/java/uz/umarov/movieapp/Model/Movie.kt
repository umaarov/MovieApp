package uz.umarov.movieapp.Model

class Movie(var title: String, var date: String, var author: String, var desc: String) {
}